﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3_KSP
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Поликлиника;Trusted_Connection=True;");
            SqlCommand com = con.CreateCommand();
            com.CommandType = CommandType.StoredProcedure;
            com.CommandText = "InsertDesease";
            con.Open();
            com.Parameters.Add("@code", SqlDbType.NChar).Value = textDesease.Text;
            com.Parameters.Add("@desease", SqlDbType.NChar).Value = textName.Text;
            com.Parameters.Add("@symptom", SqlDbType.NChar).Value = textSym.Text;
            SqlDataReader reader = com.ExecuteReader();
            listBox1.Items.Clear();
            listBox1.Items.Add("Добавление болезни в таблицу: ");
            listBox1.Items.Add("");
            while (reader.Read())
            {
                listBox1.Items.Add(reader["Код болезни"].ToString().Trim() + "\t" +
                    reader["Название болезни"].ToString().Trim() + "\t" +
                    reader["Название болезни"].ToString().Trim());
            }
            reader.Close();
            con.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Lab3_KSP
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Поликлиника;Trusted_Connection=True;");
            con.Open();
            SqlCommand com = con.CreateCommand();
            com.CommandType = CommandType.StoredProcedure;
            com.CommandText = "DeleteDesease";
            com.Parameters.Add("@NUM", SqlDbType.NChar).Value = textBox1.Text;
            com.Parameters.Add("@CODE", SqlDbType.Int);
            com.Parameters["@CODE"].Direction = ParameterDirection.ReturnValue;
            listOfGoods.Items.Clear();
            listOfGoods.Items.Add("Удаление болезни из МКБ: ");
            listOfGoods.Items.Add("");
            listOfGoods.Items.Add("");
            listOfGoods.Items.Add("");
            SqlDataReader reader = com.ExecuteReader();
            while (reader.Read())
            {
                listOfGoods.Items.Add(reader["Код болезни"].ToString().Trim() + "\t" +
                    reader["Название болезни"].ToString().Trim() + "\t" +
                    reader["Название болезни"].ToString().Trim());
            }
            reader.Close();
            String message;
            switch (Convert.ToString(com.Parameters["@CODE"].Value))
            {
                case "1":
                    message = "Информация о белзни содержится в другой таблице";
                    break;
                case "2":
                    message = "Успешное удаление";
                    break;
                case "3":
                    message = "Такой болезни нет в таблице";
                    break;
                default:
                    message = "Неизвестное сообщение";
                    break;
            }
            listOfGoods.Items[2] = message;
            con.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

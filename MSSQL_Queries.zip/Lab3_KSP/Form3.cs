﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3_KSP
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Поликлиника;Trusted_Connection=True;");
            SqlCommand com = con.CreateCommand();
            com.CommandType = CommandType.StoredProcedure;
            com.CommandText = "UpdateOklad";
            con.Open();
            com.Parameters.Add("@CODE", SqlDbType.Int);
            com.Parameters.Add("@SPEC", SqlDbType.NChar).Value = textBox1.Text;
            com.Parameters["@CODE"].Direction = ParameterDirection.ReturnValue;
            SqlDataReader reader = com.ExecuteReader();
            listBox1.Items.Clear();
            listBox1.Items.Add("Увеличение оклада в 1.3 раза: ");
            listBox1.Items.Add("");
            listBox1.Items.Add("");
            listBox1.Items.Add("");
            while (reader.Read())
            {
                listBox1.Items.Add(reader["ФИО"].ToString().Trim() + "\t" +
                    reader["Специальность"].ToString().Trim() + "\t" +
                    reader["Оклад"].ToString().Trim() + "\t" +
                    reader["Номер телефона"].ToString().Trim());
            }
            reader.Close();
            String message;
            switch (Convert.ToInt32(com.Parameters["@CODE"].Value))
            {
                case 1:
                    message = "Успешное обновление";
                    break;
                case -1:
                    message = "Таких врачей нет в таблице";
                    break;
                default:
                    message = "Неизвестное сообщение";
                    break;
            }
            listBox1.Items[2] = message;
            con.Close();
        }
    }
}
